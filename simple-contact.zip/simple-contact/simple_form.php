<?php
/**
 * Plugin Name: CF7 Form Trap
 * Plugin URI: https://github.com/yttechiepress/cf7-trap-api
 * Author: Techiepress
 * Author URI: https://github.com/yttechiepress/cf7-trap-api
 * Description: Get CF7 Data and send to API
 * Version: 0.1.0
 * License: GPL2
 * License URL: http://www.gnu.org/licenses/gpl-2.0.txt
 * text-domain: cf7-trap-api
*/

defined( 'ABSPATH' ) or die( 'Unauthorized access!' );


function my_action_wpcf7_before_send_mail( $contact_form ) { 
    // to get form id
   $form_id  = $contact_form->id();

    // to get submission data $posted_data is asociative array
    $submission = WPCF7_Submission::get_instance(); 
    $posted_data = $submission->get_posted_data();

    $arr = [];
    $i=0;

    foreach($posted_data as $x => $val) {
        $arr[$i] = $val;
        $i++;
    }

    global $wpdb;
    $result = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}wp_CARDINALS_CRM");


    $credentials = [
        'grant_type' => 'password',
        'client_id' =>  $result[0]->client_id,
        'client_secret' =>  $result[0]->client_secret,
        'username' => $result[0]->username,
        'password' => $result[0]->password
    ];

    // Init the connection
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$result[0]->domain);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($credentials));
    // Append the headers
    $headers = array();
    $headers[] = "Content-Type: application/json";
    $headers[] = "Accept: application/json";
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    // Get the connection
    $result = curl_exec($ch);
    // Prepare the data
    
    $data = json_decode($result, true);

    $token_type = $data["token_type"];
    
    $access_token = $data["access_token"];

    $fulltoken = $token_type.' '.trim($access_token);


    // Handle the error
    if (curl_errno($ch)) {
        echo "Error:" . curl_error($ch);
    }
    // Close the connection
    curl_close($ch);

    $DataForm = [
        'title'         => $arr[0],
        'first_name'    => $arr[1],
        'last_name'     => $arr[2],
        'full_name'     => $arr[3],
        'description'   => $arr[4],
        "phones" => array(
            "phone" => array(
                "phone" => "01007788368",
                "country_code" => 'EG'
            ),
        ),
        'social_accounts' => array(
            "social_account" => array(
                "social_account" => "hello@8worx.com",
                "account_type_id" => "22"
            ),
        ),
    ];

    // Init the connection
    $post = curl_init();

    curl_setopt($post, CURLOPT_URL, "https://8worxcrm.com/api/v1/lead_generation/web_form_routings/storeLead");
    curl_setopt($post, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($post, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($post, CURLOPT_POST, 1);
    curl_setopt($post, CURLOPT_POSTFIELDS, json_encode($DataForm));

    // Append the headers
    $headerspost = array();
    $headerspost[] = "Content-Type: application/json";
    $headerspost[] = "Accept: application/json";
    $headerspost[] = "Authorization:".$fulltoken;

    

    curl_setopt($post, CURLOPT_HTTPHEADER, $headerspost);
    
    // Get the connection
    $result2 = curl_exec($post);

    print_r($result2);
    
    // Prepare the data
    $data2 = json_decode($result2, true);

    // Handle the error
    if (curl_errno($post)) {
        echo "Error:" . curl_error($post);
    }

    // Close the connection
    curl_close($post);


}

add_action( 'wpcf7_before_send_mail', 'my_action_wpcf7_before_send_mail', 15, 3 );
