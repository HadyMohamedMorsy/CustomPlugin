<?php
/**
 * Plugin Name: CF7 Form Trap
 * Author: Hady Mohamed
 * Description: Get CF7 Data and send to API 8x CRM
 * Version: 1.1.0
 * License: GPL2
*/

defined( 'ABSPATH' ) or die( 'Unauthorized access!' );


function my_action_wpcf7_before_send_mail( $contact_form ) { 
    
    $baseUrl = "https://8x.8worxcrm.com/api/v1/";
    $contact_form->id();

    // to get submission data $posted_data is associative array
    $submission = WPCF7_Submission::get_instance(); 
    $posted_data = $submission->get_posted_data();

    $arr = [];
    $i=0;

    foreach($posted_data as $x => $val) {
        $arr[$i] = $val;
        $i++;
    }

    global $wpdb;
    $getCredentialToTakeToken = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}wp_CARDINALS_CRM"); //getCredentialToTakeToken

    //credentials 
    $credentials = [
        'grant_type' => 'password',
        'client_id' =>  $getCredentialToTakeToken[0]->client_id,
        'client_secret' =>  $getCredentialToTakeToken[0]->client_secret,
        'username' => $getCredentialToTakeToken[0]->username,
        'password' => $getCredentialToTakeToken[0]->password
    ];

    // Init the connection
    $Token = curl_init();
    curl_setopt($Token, CURLOPT_URL,$getCredentialToTakeToken[0]->domain);
    curl_setopt($Token, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($Token, CURLOPT_POST, 1);
    curl_setopt($Token, CURLOPT_POSTFIELDS, json_encode($credentials));

    // Append the headers
    $headers = array();
    $headers[] = "Content-Type: application/json";
    $headers[] = "Accept: application/json";
    curl_setopt($Token, CURLOPT_HTTPHEADER, $headers);

    // retrieveToken
    $retrieveToken = curl_exec($Token);
    $getCredential = json_decode($retrieveToken, true);
    $token_type = $getCredential["token_type"];
    $access_token = $getCredential["access_token"];
    $callToken = $token_type.' '.trim($access_token);


    // Handle the error
    if (curl_errno($Token)) {
        echo "Error:" . curl_error($Token);
    }
    // Close the connection
    curl_close($Token);

    // DataForm to CRM 8x
    $DataForm = [
        'title'         => $arr[0],
        'first_name'    => $arr[1],
        'last_name'     => $arr[2],
        'full_name'     => $arr[3],
        'description'   => $arr[4],
        "phones" => array(
            "phone" => array(
                "phone" => "01007788368",
                "country_code" => 'EG'
            ),
        ),
        'social_accounts' => array(
            "social_account" => array(
                "social_account" => "hello@8worx.com",
                "account_type_id" => "22"
            ),
        ),
    ];

    // Init the connection
    $postDataForm = curl_init();

    curl_setopt($postDataForm, CURLOPT_URL, "{$baseUrl}lead_generation/web_form_routings/storeLead");
    curl_setopt($postDataForm, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($postDataForm, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($postDataForm, CURLOPT_POST, 1);
    curl_setopt($postDataForm, CURLOPT_POSTFIELDS, json_encode($DataForm));

    // Append the headers
    $headersDataForm = array();
    $headersDataForm[] = "Content-Type: application/json";
    $headersDataForm[] = "Accept: application/json";
    $headersDataForm[] = "Authorization:".$callToken;


    curl_setopt($postDataForm, CURLOPT_HTTPHEADER, $headersDataForm);
    
    curl_exec($postDataForm);

    if (curl_errno($postDataForm)) {
        echo "Error:" . curl_error($postDataForm);
    }

    curl_close($postDataForm);

}

add_action( 'wpcf7_before_send_mail', 'my_action_wpcf7_before_send_mail', 15, 3 );
