<?php
/*
Plugin Name: Credential_8x
Description: integration with crm to send data
Author: Hady Mohamed
Version: 1.1
License: GPL2
*/
defined( 'ABSPATH' ) or die( 'Unauthorized access!' );

function enqueue(){

    wp_enqueue_style('boot' ,plugin_dir_url( __FILE__ ) . 'assist/bootstrap.min.css' , array(), false , 'all');

    wp_enqueue_style('mypluginstyle' ,  plugin_dir_url( __FILE__ ) . 'assist/main.css' , array(), false);

    wp_enqueue_script('mypluginscript' ,  plugin_dir_url( __FILE__ ) . 'assist/main.js' , array(), false , true);

    wp_register_script('bootstrapjs' ,  plugin_dir_url( __FILE__ ) . 'assist/bootstrap.bundle.min.js' , array() , false , true);

    wp_enqueue_script('bootstrapjs');

}
add_action('admin_menu', 'setup_menu');

function setup_menu(){
    add_menu_page( '8x', '8x', 'manage_options', '8x', 'FormBuilder' );
}

function FormBuilder() {
    $current_user = wp_get_current_user();
    ?>
    <form class="container" action="" method="POST">
        <h1 class="mt-5 mb-5"> Submit Your Credential To CRM 8X</h1>
        <div class="form-group mt-5 mb-5">

            <label for="exampleInputEmail1" class="mb-3 label-form">client_id</label>
            <input type="hidden" value="<?php echo $current_user->ID ?>" name="current_user">
            
            <input type="number" class="form-control input-crm"  placeholder="client_id" name="client_id">
        </div>
        <div class="form-group mt-5 mb-5">

            <label for="exampleInputPassword1" class="mb-3 label-form">client_secret</label>

            <input type="text" class="form-control input-crm"  placeholder="client_secret" name="client_secret">
        </div>
        <div class="form-group mt-5 mb-5">

            <label for="exampleInputPassword1" class="mb-3 label-form">Domain</label>

            <input type="text" class="form-control input-crm"  placeholder="Domain" name="Domain">
        </div>
        <div class="form-group mt-5 mb-5">

            <label for="exampleInputPassword1" class="mb-3 label-form">username</label>

            <input type="text" class="form-control input-crm"  placeholder="username" name="username">
        </div>
        <div class="form-group mt-5 mb-5">

            <label for="exampleInputPassword1" class="mb-3 label-form">Password</label>

            <input type="password" class="form-control input-crm"  placeholder="Password" name="Password">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    <?php
}

function sendData(){
    if(isset($_POST['client_id'])){

        // this is requested about data
        $id = $_POST['current_user'];
        $client_id = $_POST['client_id'];
        $client_secret = $_POST['client_secret'];
        $Domain = $_POST['Domain'];
        $username = $_POST['username'];
        $Password = $_POST['Password'];

        global $wpdb;
        $data = array(
        'id_user' => $id , 
        'client_id' => $client_id , 
        'client_secret' => $client_secret , 
        'domain' => $Domain , 
        'username' => $username , 
        'password' => $Password);

        // insert to table cardinals_crm
        
        if(checkExist($id) == 0){
            global $wpdb;
            $data = array('id_user' => $id , 'client_id' => $client_id , 'client_secret' => $client_secret , 'domain' => $Domain , 'username' => $username , 'password' => $Password);
            // insert to table cardinals_crm
            $wpdb->insert($wpdb->prefix.'CARDINALS_CRM', $data);
        }else{
            global $wpdb;
            $result = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}CARDINALS_CRM");
            $crm_entry_id = $result[0]->crm_entry_id;
            $data = array('id_user' => $id , 'client_id' => $client_id , 'client_secret' => $client_secret , 'domain' => $Domain , 'username' => $username , 'password' => $Password);
            $location = array( 'crm_entry_id' => $crm_entry_id );
            $wpdb->update($wpdb->prefix.'CARDINALS_CRM',$data,$location);
        }   
        
    }
}

// reusable Functions
function checkExist($id){
    global $wpdb;
    $rowcount = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}CARDINALS_CRM WHERE id_user= {$id}");
    return $rowcount;
}


function Create_table(){
    global $wpdb;
    require_once(ABSPATH.'wp-admin/includes/upgrade.php');
    $table_name = $wpdb->prefix.'CARDINALS_CRM';
    $charset = $wpdb->get_charset_collate();
    if( $wpdb->get_var( "SHOW TABLES LIKE ".$table_name ) != $table_name ){
        $sql = "CREATE TABLE $table_name ( 
            crm_entry_id INT(10) NOT NULL AUTO_INCREMENT,
            id_user INT(10) NOT NULL,
            client_id INT(10) NOT NULL,
            client_secret VARCHAR(100) NOT NULL,
            domain VARCHAR(100) NOT NULL,
            username VARCHAR(100) NOT NULL,
            password VARCHAR(100) NOT NULL,
            PRIMARY KEY (crm_entry_id)
        ) $charset;";
        dbDelta( $sql );
    };
}

function activate() {
    enqueue();
    Create_table();
    sendData();
}

function deactivated(){
    flush_rewrite_rules();
}

register_activation_hook(__FILE__ , 'activate');
register_activation_hook(__FILE__ , 'deactivated');

